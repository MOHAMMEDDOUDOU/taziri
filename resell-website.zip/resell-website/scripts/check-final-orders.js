const { neon } = require("@neondatabase/serverless");
require('dotenv').config();

const sql = neon(process.env.NEON_DATABASE_URL);

async function checkFinalOrders() {
  try {
    console.log('🔍 التحقق من جميع الطلبات في جدول orders...');
    
    const orders = await sql`
      SELECT 
        id, 
        item_name, 
        customer_name, 
        phone_number, 
        quantity, 
        unit_price, 
        total_amount, 
        delivery_type, 
        wilaya, 
        commune, 
        status, 
        created_at,
        order_link
      FROM orders 
      ORDER BY created_at DESC
    `;
    
    console.log(`📊 إجمالي الطلبات: ${orders.length}`);
    console.log('\n📋 تفاصيل الطلبات:');
    
    orders.forEach((order, index) => {
      console.log(`\n${index + 1}. طلب رقم: ${order.id.substring(0, 8)}...`);
      console.log(`   العميل: ${order.customer_name} - ${order.phone_number}`);
      console.log(`   المنتج: ${order.item_name}`);
      console.log(`   الكمية: ${order.quantity}`);
      console.log(`   السعر: ${order.unit_price} دج`);
      console.log(`   المجموع: ${order.total_amount} دج`);
      console.log(`   التوصيل: ${order.delivery_type === 'home' ? 'للمنزل' : 'من المكتب'}`);
      console.log(`   الولاية: ${order.wilaya}`);
      console.log(`   البلدية: ${order.commune || 'غير محدد'}`);
      console.log(`   الحالة: ${order.status}`);
      console.log(`   الرابط: ${order.order_link}`);
      console.log(`   التاريخ: ${new Date(order.created_at).toLocaleString('ar-SA')}`);
    });
    
  } catch (error) {
    console.error('❌ خطأ في التحقق من الطلبات:', error);
  } finally {
    process.exit(0);
  }
}

checkFinalOrders();
