const { neon } = require("@neondatabase/serverless");
require('dotenv').config();

const sql = neon(process.env.NEON_DATABASE_URL);

async function checkOrders() {
  try {
    console.log('🔍 التحقق من جميع الطلبات المحفوظة...');
    
    const orders = await sql`
      SELECT 
        id, 
        order_number, 
        customer_name, 
        customer_phone, 
        item_name, 
        quantity, 
        total_amount, 
        delivery_type, 
        wilaya, 
        commune, 
        status, 
        created_at 
      FROM customer_orders 
      ORDER BY created_at DESC
    `;
    
    console.log(`📊 إجمالي الطلبات: ${orders.length}`);
    console.log('\n📋 تفاصيل الطلبات:');
    
    orders.forEach((order, index) => {
      console.log(`\n${index + 1}. طلب رقم: ${order.order_number}`);
      console.log(`   العميل: ${order.customer_name} - ${order.customer_phone}`);
      console.log(`   المنتج: ${order.item_name}`);
      console.log(`   الكمية: ${order.quantity}`);
      console.log(`   المجموع: ${order.total_amount} دج`);
      console.log(`   التوصيل: ${order.delivery_type === 'home' ? 'للمنزل' : 'من المكتب'}`);
      console.log(`   الولاية: ${order.wilaya}`);
      console.log(`   البلدية: ${order.commune || 'غير محدد'}`);
      console.log(`   الحالة: ${order.status}`);
      console.log(`   التاريخ: ${new Date(order.created_at).toLocaleString('ar-SA')}`);
    });
    
  } catch (error) {
    console.error('❌ خطأ في التحقق من الطلبات:', error);
  } finally {
    process.exit(0);
  }
}

checkOrders();
