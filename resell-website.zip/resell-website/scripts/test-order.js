const { neon } = require("@neondatabase/serverless");
require('dotenv').config();

const sql = neon(process.env.NEON_DATABASE_URL);

async function testOrder() {
  try {
    console.log('🧪 اختبار حفظ طلبية في قاعدة البيانات...');
    
    const testOrder = {
      resell_link_id: 'test-slug-123',
      item_type: 'product',
      item_id: 'item-456',
      item_name: 'هاتف ذكي جديد',
      original_price: 25000,
      reseller_price: 22000,
      quantity: 2,
      total_amount: 44000,
      seller_id: 'seller-789',
      seller_name: 'أحمد محمد',
      seller_phone: '0555123456',
      customer_name: 'محمد علي',
      customer_phone: '0555987654',
      delivery_type: 'home',
      wilaya: 16,
      commune: 'الجزائر الوسطى',
      notes: 'طلب تجريبي للاختبار'
    };

    const result = await sql`
      INSERT INTO customer_orders (
        resell_link_id, item_type, item_id, item_name, original_price, 
        reseller_price, quantity, total_amount, seller_id, seller_name, 
        seller_phone, customer_name, customer_phone, delivery_type, 
        wilaya, commune, notes, order_number, status, created_at
      ) VALUES (
        ${testOrder.resell_link_id}, ${testOrder.item_type}, ${testOrder.item_id}, ${testOrder.item_name}, ${testOrder.original_price}, 
        ${testOrder.reseller_price}, ${testOrder.quantity}, ${testOrder.total_amount}, ${testOrder.seller_id}, ${testOrder.seller_name}, 
        ${testOrder.seller_phone}, ${testOrder.customer_name}, ${testOrder.customer_phone}, ${testOrder.delivery_type}, 
        ${testOrder.wilaya}, ${testOrder.commune}, ${testOrder.notes}, 
        'TEST-' || EXTRACT(EPOCH FROM NOW())::bigint, 'pending', NOW()
      ) RETURNING *
    `;

    console.log('✅ تم حفظ الطلبية بنجاح!');
    console.log('📋 تفاصيل الطلبية:', result[0]);
    
    // اختبار جلب الطلبية
    console.log('\n🔍 اختبار جلب الطلبية...');
    const savedOrder = await sql`
      SELECT * FROM customer_orders WHERE resell_link_id = ${testOrder.resell_link_id} ORDER BY created_at DESC LIMIT 1
    `;
    
    if (savedOrder.length > 0) {
      console.log('✅ تم جلب الطلبية بنجاح!');
      console.log('📋 الطلبية المحفوظة:', savedOrder[0]);
    } else {
      console.log('❌ لم يتم العثور على الطلبية');
    }
    
  } catch (error) {
    console.error('❌ خطأ في اختبار الطلبية:', error);
  } finally {
    process.exit(0);
  }
}

testOrder();
