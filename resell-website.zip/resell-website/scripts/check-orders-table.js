const { neon } = require("@neondatabase/serverless");
require('dotenv').config();

const sql = neon(process.env.NEON_DATABASE_URL);

async function checkOrdersTable() {
  try {
    console.log('🔍 قراءة الطلبيات من جدول orders...');
    
    // قراءة هيكل الجدول
    console.log('\n📋 هيكل جدول orders:');
    const tableStructure = await sql`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name = 'orders' 
      ORDER BY ordinal_position
    `;
    
    tableStructure.forEach(col => {
      console.log(`   ${col.column_name}: ${col.data_type} (${col.is_nullable === 'YES' ? 'nullable' : 'NOT NULL'})`);
    });
    
    // قراءة البيانات الموجودة
    console.log('\n📊 البيانات الموجودة في جدول orders:');
    const orders = await sql`SELECT * FROM orders ORDER BY created_at DESC LIMIT 10`;
    
    console.log(`إجمالي السجلات: ${orders.length}`);
    
    orders.forEach((order, index) => {
      console.log(`\n${index + 1}. سجل رقم: ${order.id}`);
      console.log('   البيانات:', JSON.stringify(order, null, 2));
    });
    
    // قراءة من جدول customer_orders أيضاً
    console.log('\n🔍 قراءة الطلبيات من جدول customer_orders...');
    const customerOrders = await sql`SELECT * FROM customer_orders ORDER BY created_at DESC LIMIT 5`;
    
    console.log(`إجمالي السجلات في customer_orders: ${customerOrders.length}`);
    
    customerOrders.forEach((order, index) => {
      console.log(`\n${index + 1}. طلب رقم: ${order.order_number}`);
      console.log('   البيانات:', JSON.stringify(order, null, 2));
    });
    
  } catch (error) {
    console.error('❌ خطأ في قراءة الجداول:', error);
  } finally {
    process.exit(0);
  }
}

checkOrdersTable();
