-- إنشاء جدول الطلبات
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  slug VARCHAR(255) UNIQUE NOT NULL,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  original_price DECIMAL(10, 2),
  condition VARCHAR(100) NOT NULL,
  category VARCHAR(100) NOT NULL,
  brand VARCHAR(200),
  seller_name VARCHAR(200) NOT NULL,
  seller_phone VARCHAR(50),
  seller_email VARCHAR(200),
  location VARCHAR(200),
  images TEXT[], -- مصفوفة من روابط الصور
  status VARCHAR(50) DEFAULT 'available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء فهرس على slug للبحث السريع
CREATE INDEX IF NOT EXISTS idx_orders_slug ON orders(slug);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- إنشاء جدول طلبات العملاء
CREATE TABLE IF NOT EXISTS customer_orders (
  id SERIAL PRIMARY KEY,
  resell_link_id VARCHAR(255) NOT NULL,
  item_type VARCHAR(100) NOT NULL,
  item_id VARCHAR(255) NOT NULL,
  item_name VARCHAR(500) NOT NULL,
  original_price DECIMAL(10, 2) NOT NULL,
  reseller_price DECIMAL(10, 2) NOT NULL,
  quantity INTEGER NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL,
  seller_id VARCHAR(255),
  seller_name VARCHAR(200),
  seller_phone VARCHAR(50),
  customer_name VARCHAR(200) NOT NULL,
  customer_phone VARCHAR(50) NOT NULL,
  delivery_type VARCHAR(50) NOT NULL,
  wilaya INTEGER NOT NULL,
  commune VARCHAR(200),
  notes TEXT,
  order_number VARCHAR(100) UNIQUE NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء فهارس لجدول طلبات العملاء
CREATE INDEX IF NOT EXISTS idx_customer_orders_resell_link_id ON customer_orders(resell_link_id);
CREATE INDEX IF NOT EXISTS idx_customer_orders_status ON customer_orders(status);
CREATE INDEX IF NOT EXISTS idx_customer_orders_order_number ON customer_orders(order_number);
