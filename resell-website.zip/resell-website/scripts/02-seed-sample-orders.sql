-- إضافة بيانات تجريبية للطلبات
INSERT INTO orders (slug, title, description, price, original_price, condition, category, brand, seller_name, seller_phone, seller_email, location, images, status) VALUES
('iphone-14-pro-max', 'آيفون 14 برو ماكس 256 جيجا', 'آيفون 14 برو ماكس بحالة ممتازة، مستخدم بعناية، مع جميع الإكسسوارات الأصلية والكرتونة', 3500.00, 4200.00, 'ممتاز', 'هواتف ذكية', 'Apple', 'أحمد محمد', '+966501234567', 'ahmed@example.com', 'الرياض، السعودية', ARRAY['/placeholder.svg?height=400&width=400'], 'available'),

('macbook-air-m2', 'ماك بوك اير M2 2022', 'ماك بوك اير M2 شاشة 13 انش، 8 جيجا رام، 256 جيجا SSD، بحالة جيدة جداً', 4800.00, 5500.00, 'جيد جداً', 'أجهزة كمبيوتر', 'Apple', 'سارة أحمد', '+966509876543', 'sara@example.com', 'جدة، السعودية', ARRAY['/placeholder.svg?height=400&width=400'], 'available'),

('ps5-console', 'بلايستيشن 5 مع يدتين', 'جهاز بلايستيشن 5 مع يدتين إضافيتين و 3 ألعاب، بحالة ممتازة', 2200.00, 2800.00, 'ممتاز', 'ألعاب فيديو', 'Sony', 'خالد العلي', '+966512345678', 'khalid@example.com', 'الدمام، السعودية', ARRAY['/placeholder.svg?height=400&width=400'], 'available'),

('samsung-s23-ultra', 'سامسونج جالاكسي S23 الترا', 'سامسونج S23 الترا 512 جيجا، لون أسود، مع القلم، بحالة جيدة', 2800.00, 3200.00, 'جيد', 'هواتف ذكية', 'Samsung', 'فاطمة حسن', '+966507654321', 'fatima@example.com', 'مكة، السعودية', ARRAY['/placeholder.svg?height=400&width=400'], 'available');
