const { neon } = require("@neondatabase/serverless");
require('dotenv').config();

const sql = neon(process.env.NEON_DATABASE_URL);

async function createTables() {
  try {
    console.log('إنشاء جدول طلبات العملاء...');
    
    await sql`
      CREATE TABLE IF NOT EXISTS customer_orders (
        id SERIAL PRIMARY KEY,
        resell_link_id VARCHAR(255) NOT NULL,
        item_type VARCHAR(100) NOT NULL,
        item_id VARCHAR(255) NOT NULL,
        item_name VARCHAR(500) NOT NULL,
        original_price DECIMAL(10, 2) NOT NULL,
        reseller_price DECIMAL(10, 2) NOT NULL,
        quantity INTEGER NOT NULL,
        total_amount DECIMAL(10, 2) NOT NULL,
        seller_id VARCHAR(255),
        seller_name VARCHAR(200),
        seller_phone VARCHAR(50),
        customer_name VARCHAR(200) NOT NULL,
        customer_phone VARCHAR(50) NOT NULL,
        delivery_type VARCHAR(50) NOT NULL,
        wilaya INTEGER NOT NULL,
        commune VARCHAR(200),
        notes TEXT,
        order_number VARCHAR(100) UNIQUE NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;

    console.log('إنشاء الفهارس...');
    
    await sql`CREATE INDEX IF NOT EXISTS idx_customer_orders_resell_link_id ON customer_orders(resell_link_id)`;
    await sql`CREATE INDEX IF NOT EXISTS idx_customer_orders_status ON customer_orders(status)`;
    await sql`CREATE INDEX IF NOT EXISTS idx_customer_orders_order_number ON customer_orders(order_number)`;

    console.log('✅ تم إنشاء الجداول بنجاح!');
    
  } catch (error) {
    console.error('❌ خطأ في إنشاء الجداول:', error);
  } finally {
    process.exit(0);
  }
}

createTables();
