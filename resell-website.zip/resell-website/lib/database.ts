import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.NEON_DATABASE_URL!)

export interface Order {
  id: number
  slug: string
  title: string
  description: string | null
  price: number
  original_price: number | null
  condition: string
  category: string
  brand: string | null
  seller_name: string
  seller_phone: string | null
  seller_email: string | null
  location: string | null
  images: string[]
  status: string
  created_at: string
  updated_at: string
}

export async function getOrderBySlug(slug: string): Promise<Order | null> {
  try {
    const result = await sql`
      SELECT * FROM orders 
      WHERE slug = ${slug} AND status = 'available'
      LIMIT 1
    `

    return (result[0] as Order) || null
  } catch (error) {
    console.error("خطأ في جلب الطلب:", error)
    return null
  }
}

export async function getAllOrders(): Promise<Order[]> {
  try {
    const result = await sql`
      SELECT * FROM orders 
      WHERE status = 'available'
      ORDER BY created_at DESC
    `

    return result as Order[]
  } catch (error) {
    console.error("خطأ في جلب الطلبات:", error)
    return []
  }
}
