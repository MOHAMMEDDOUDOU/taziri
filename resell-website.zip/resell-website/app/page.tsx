export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-2xl">404: page could not found</h1>
    </div>
  )
}
