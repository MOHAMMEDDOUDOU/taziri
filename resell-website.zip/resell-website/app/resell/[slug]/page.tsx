'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Phone, MessageCircle, ShoppingCart, Star, User, MapPin, Mail, Heart } from 'lucide-react';
import Image from 'next/image';
import { WILAYAS, COMMUNES_BY_CODE } from "@/lib/locations";

interface ResellLinkData {
  link: {
    id: string;
    slug: string;
    item_type: string;
    item_id: string;
    reseller: {
      user_id: string | null;
      name: string | null;
      phone: string | null;
    };
    custom_price: number | null;
    is_active: boolean;
    expires_at: string | null;
    stats: {
      views: number;
      clicks: number;
    };
  };
  item: {
    id: string;
    name: string;
    description: string | null;
    original_price: number;
    custom_price: number | null;
    final_price: number;
    image_url: string | null;
    category: string | null;
    stock_quantity: number;
  };
}

export default function ResellLinkPage() {
  const params = useParams();
  const [data, setData] = useState<ResellLinkData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  
  // نموذج الطلب
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [wilaya, setWilaya] = useState(16);
  const [commune, setCommune] = useState("");
  const [deliveryType, setDeliveryType] = useState("home");
  const [address, setAddress] = useState("");
  const [availableCommunes, setAvailableCommunes] = useState<string[]>([]);

  // بيانات الولايات والبلديات (مبسطة)
  // const WILAYAS = [
  //   { code: 16, name: "الجزائر" },
  //   { code: 31, name: "وهران" },
  //   { code: 48, name: "بجاية" },
  //   { code: 19, name: "سطيف" },
  //   { code: 6, name: "بشار" },
  //   { code: 42, name: "تيبازة" },
  //   { code: 26, name: "مستغانم" },
  //   { code: 22, name: "سيدي بلعباس" },
  //   { code: 21, name: "سكيكدة" },
  //   { code: 41, name: "سوق أهراس" },
  // ];

  // const COMMUNES_BY_CODE: Record<number, string[]> = {
  //   16: ["الجزائر الوسطى", "باب الوادي", "بولوغين", "الحراش", "براقي", "الدار البيضاء"],
  //   31: ["وهران", "بئر الجير", "عين الترك", "أرزيو", "بوتليليس", "مرسى الحجاج"],
  //   48: ["بجاية", "أميزور", "فرعون", "تيشي", "صدوق", "شلاطة العذاورة"],
  //   19: ["سطيف", "عين التوتة", "مروانة", "تكوت", "نقاوس", "عين ياقوت"],
  //   6: ["بشار", "بني ونيف", "البيض", "أولاد خضير", "تاغيت", "بني عباس"],
  //   42: ["تيبازة", "شرشال", "دواودة", "فوكة", "سيدي عمار", "عين تاقورايت"],
  //   26: ["مستغانم", "ماسكارا", "عين تادلس", "بوقايد", "سيدي علي", "عشعاشة"],
  //   22: ["سيدي بلعباس", "عين البرد", "سيدي خالد", "رأس الماء", "عين الثريد", "مولاي سليمان"],
  //   21: ["سكيكدة", "أم البواقي", "عين قشرة", "القل", "الزيتونة", "الحروش"],
  //   41: ["سوق أهراس", "سدراتة", "أم العظائم", "عين سلطان", "أولاد إدريس", "تاورة"],
  // };

  // تحديث البلديات المتاحة عند تغيير الولاية
  useEffect(() => {
    const communes = COMMUNES_BY_CODE[wilaya] || [];
    setAvailableCommunes(communes);
    setCommune(""); // إعادة تعيين البلدية عند تغيير الولاية
  }, [wilaya]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const slug = params.slug as string;
        
        // جلب البيانات من API المحلي
        const response = await fetch(`/api/resell-links/${slug}`);
        
        if (!response.ok) {
          if (response.status === 404) {
            setError('الرابط غير موجود أو منتهي الصلاحية');
          } else {
            setError('حدث خطأ في جلب البيانات');
          }
          setLoading(false);
          return;
        }
        
        const apiData = await response.json();
        
        // تأخير صغير لتجنب مشاكل Hydration
        setTimeout(() => {
          setData(apiData);
          setLoading(false);
        }, 100);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطأ غير متوقع');
        setLoading(false);
      }
    };

    if (params.slug) {
      fetchData();
    }
  }, [params.slug]);

  // حساب التكلفة المتغيرة حسب الولاية
  const selectedWilaya = WILAYAS.find(w => w.code === wilaya);
  const shipping = deliveryType === "home" 
    ? (selectedWilaya?.tarif || 0)
    : (selectedWilaya?.stopDesk || 0);

  const unitPrice = data?.item?.custom_price || data?.item?.original_price || 0;
  const subtotal = unitPrice * quantity;
  const total = subtotal + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!data) return;
    
    if (!customerName.trim() || !customerPhone.trim()) {
      alert("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    if (deliveryType === "home" && !commune.trim()) {
      alert("يرجى اختيار البلدية");
      return;
    }

    setSubmitting(true);

    try {
      const orderData = {
        resell_link_id: data?.link?.id,
        item_type: data?.link?.item_type,
        item_id: data?.item?.id,
        item_name: data?.item?.name,
        original_price: data?.item?.original_price,
        reseller_price: data?.link?.custom_price || data?.item?.original_price,
        quantity: quantity,
        total_amount: total,
        seller_id: data?.link?.reseller?.user_id || null,
        seller_name: data?.link?.reseller?.name || null,
        seller_phone: data?.link?.reseller?.phone || null,
        customer_name: customerName.trim(),
        customer_phone: customerPhone.replace(/\s/g, ""),
        delivery_type: deliveryType,
        wilaya: wilaya,
        commune: deliveryType === 'home' ? commune?.trim() : null,
        notes: `طلب من رابط البيع: ${params.slug}`
      };

      const apiUrl = `${window.location.origin}/api/orders`;
      console.log('submit:start', { apiUrl, orderData });

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        body: JSON.stringify(orderData),
      });

      console.log('submit:response', { status: response.status });

      if (response.ok) {
        const result = await response.json();
        console.log('submit:success', result);
        alert(`تم إرسال الطلب بنجاح! رقم الطلب: ${result.order.order_number}`);
        
        // إعادة تعيين النموذج
        setQuantity(1);
        setCustomerName("");
        setCustomerPhone("");
        setWilaya(16);
        setCommune("");
        setDeliveryType('home');
      } else {
        const raw = await response.text();
        let parsed: any = null;
        try { parsed = JSON.parse(raw); } catch {}
        console.error('فشل إرسال الطلب:', { status: response.status, body: raw });
        alert((parsed && parsed.error) || 'حدث خطأ أثناء إرسال الطلب');
      }
    } catch (error) {
      console.error('خطأ في إرسال الطلب:', error);
      alert("حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.");
    } finally {
      console.log('submit:done');
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center p-6">
            <div className="text-red-500 mb-4">
              <MessageCircle className="h-12 w-12 mx-auto" />
            </div>
            <h2 className="text-xl font-semibold mb-2">خطأ</h2>
            <p className="text-gray-600">{error || 'الرابط غير موجود أو منتهي الصلاحية'}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Header بسيط */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">طلب المنتج</h1>
          <p className="text-gray-600">أكمل طلبك الآن</p>
        </div>

        <div className="space-y-6">
          {/* معلومات المنتج - مبسطة */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            {/* صورة المنتج */}
            <div className="relative h-80 bg-gray-100 rounded-lg overflow-hidden mb-4">
              {data?.item?.image_url ? (
                <Image
                  src={data.item.image_url}
                  alt={data?.item?.name || 'المنتج'}
                  fill
                  className="object-cover"
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center text-gray-400">
                    <ShoppingCart className="h-16 w-16 mx-auto mb-2" />
                    <p>لا توجد صورة</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* اسم المنتج والسعر */}
            <div className="text-center">
              <h2 className="text-xl font-bold text-gray-800 mb-3">
                {data?.item?.name || 'المنتج'}
              </h2>
              <div className="text-2xl font-bold text-green-600 mb-1">
                {(data?.item?.custom_price || data?.item?.original_price || 0).toLocaleString('fr-FR')} دج
              </div>
              {data?.item?.original_price && data?.item?.custom_price && data?.item?.original_price > data?.item?.custom_price && (
                <div className="text-sm text-gray-500 line-through">
                  {data.item.original_price.toLocaleString('fr-FR')} دج
                </div>
              )}
            </div>
          </div>

          {/* استمارة الطلب - بسيطة ومحترفة */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-6 text-center">معلومات الطلب</h3>
            
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* الاسم والهاتف */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الاسم الكامل *
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="الاسم الكامل"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم الهاتف *
                  </label>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              {/* الكمية */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الكمية</label>
                <div className="flex items-center justify-center space-x-3 space-x-reverse max-w-xs mx-auto">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300"
                  >
                    -
                  </button>
                  <span className="text-lg font-semibold min-w-[2rem] text-center">{quantity}</span>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* نوع التوصيل */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  نوع التوصيل *
                </label>
                <select
                  value={deliveryType}
                  onChange={(e) => setDeliveryType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="home">توصيل للمنزل</option>
                  <option value="pickup">استلام من المكتب</option>
                </select>
              </div>

              {/* الولاية والبلدية */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">الولاية</label>
                  <select
                    value={wilaya}
                    onChange={(e) => setWilaya(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {WILAYAS.map((wilaya) => (
                      <option key={wilaya.code} value={wilaya.code}>
                        {wilaya.name}
                      </option>
                    ))}
                  </select>
                </div>

                {deliveryType === "home" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      البلدية *
                    </label>
                    <select
                      value={commune}
                      onChange={(e) => setCommune(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    >
                      <option value="">اختر البلدية</option>
                      {availableCommunes.map((commune) => (
                        <option key={commune} value={commune}>
                          {commune}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* ملخص السعر */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">سعر الوحدة:</span>
                    <span className="font-medium">{unitPrice.toLocaleString('fr-FR')} دج</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">الكمية:</span>
                    <span className="font-medium">{quantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      التوصيل ({deliveryType === "home" ? "للمنزل" : "من المكتب"}):
                    </span>
                    <span className="font-medium">{shipping.toLocaleString('fr-FR')} دج</span>
                  </div>
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between font-bold text-lg">
                      <span>المجموع:</span>
                      <span className="text-green-600">{total.toLocaleString('fr-FR')} دج</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* زر الإرسال */}
              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-semibold rounded-md"
                disabled={submitting}
              >
                {submitting ? (
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>جاري الإرسال...</span>
                  </div>
                ) : (
                  <span>إرسال الطلب</span>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
