import Link from "next/link"
import { AlertCircle, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader className="space-y-4">
          <div className="mx-auto w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center">
            <AlertCircle className="w-8 h-8 text-red-600 dark:text-red-400" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-slate-900 dark:text-slate-100">الطلب غير موجود</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-400 mt-2">
              لم نتمكن من العثور على الطلب المطلوب. تأكد من صحة الرابط.
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          <Button asChild className="w-full">
            <Link href="/" className="flex items-center justify-center space-x-2 space-x-reverse">
              <Home className="w-4 h-4" />
              <span>العودة للصفحة الرئيسية</span>
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
