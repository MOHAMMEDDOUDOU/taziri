import { NextRequest, NextResponse } from 'next/server';
import { neon } from "@neondatabase/serverless";

const sql = neon(process.env.NEON_DATABASE_URL!);

function normalizeDigits(input: string | null | undefined): string {
  if (!input) return '';
  const arabicIndic = '٠١٢٣٤٥٦٧٨٩';
  const easternArabicIndic = '۰۱۲۳۴۵۶۷۸۹';
  let out = '';
  for (const ch of input) {
    const i1 = arabicIndic.indexOf(ch);
    if (i1 !== -1) { out += String(i1); continue; }
    const i2 = easternArabicIndic.indexOf(ch);
    if (i2 !== -1) { out += String(i2); continue; }
    if (/\d/.test(ch)) { out += ch; continue; }
    if (/\s|[+\-()]/.test(ch)) continue;
    out += ch;
  }
  return out;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      resell_link_id,
      item_type,
      item_id,
      item_name,
      original_price,
      reseller_price,
      quantity,
      total_amount,
      seller_id,
      seller_name,
      seller_phone,
      customer_name,
      customer_phone,
      delivery_type,
      wilaya,
      commune,
      notes
    } = body;

    if (!resell_link_id || !item_type || !item_id || !item_name || 
        !original_price || !reseller_price || !quantity || !customer_name || !customer_phone || !delivery_type || !wilaya) {
      return NextResponse.json(
        { error: 'جميع الحقول المطلوبة يجب أن تكون موجودة' },
        { status: 400 }
      );
    }

    const normalizedPhone = normalizeDigits(customer_phone);
    
    // حساب التكلفة الفرعية والشحن
    const subtotal = Number(reseller_price) * Number(quantity);
    const shipping_cost = delivery_type === "home" ? 500 : 300; // تكلفة ثابتة مؤقتاً

    // إنشاء الطلب في جدول orders
    const result = await sql`
      INSERT INTO orders (
        item_type, item_id, item_name, quantity, unit_price, subtotal, 
        shipping_cost, total_amount, customer_name, phone_number, 
        wilaya, commune, delivery_type, status, reseller_price, 
        created_at, reseller_name, reseller_phone, reseller_user_id, order_link
      ) VALUES (
        ${item_type}, ${item_id}, ${item_name}, ${Number(quantity)}, ${Number(reseller_price)}, ${subtotal}, 
        ${shipping_cost}, ${Number(total_amount)}, ${customer_name}, ${normalizedPhone}, 
        ${wilaya.toString()}, ${commune || null}, ${delivery_type}, 'pending', ${Number(reseller_price)}, 
        NOW(), ${seller_name || null}, ${seller_phone || null}, ${seller_id || null}, ${resell_link_id}
      ) RETURNING *
    `;

    const order = result[0];

    return NextResponse.json({
      success: true,
      order: order
    });

  } catch (error) {
    console.error('خطأ في إنشاء الطلب:', error);
    return NextResponse.json(
      { error: 'خطأ في الخادم', details: error.message },
      { status: 500 }
    );
  }
}