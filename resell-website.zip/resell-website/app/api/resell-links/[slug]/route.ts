import { NextRequest, NextResponse } from 'next/server';
import { neon } from "@neondatabase/serverless";

const sql = neon(process.env.NEON_DATABASE_URL!);

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    if (!slug) {
      return NextResponse.json(
        { error: 'الرابط المختصر مطلوب' },
        { status: 400 }
      );
    }

    // جلب بيانات رابط إعادة البيع مع بيانات المنتج/العرض والمستخدم
    const result = await sql`
      SELECT 
        rl.id as link_id,
        rl.slug,
        rl.item_type,
        rl.product_id,
        rl.offer_id,
        rl.user_id,
        rl.reseller_price,
        p.name as product_name,
        p.description as product_description,
        p.price as product_price,
        p.image_url as product_image_url,
        p.category as product_category,
        p.stock_quantity as product_stock,
        o.name as offer_name,
        o.description as offer_description,
        o.price as offer_price,
        o.image_url as offer_image_url,
        o.category as offer_category,
        o.stock_quantity as offer_stock,
        u.full_name as reseller_name,
        u.phone_number as reseller_phone,
        rl.is_active,
        rl.created_at
      FROM resell_links rl
      LEFT JOIN products p ON rl.item_type = 'product' AND rl.product_id = p.id AND p.is_active = true
      LEFT JOIN offers o ON rl.item_type = 'offer' AND rl.offer_id = o.id
      LEFT JOIN users u ON rl.user_id = u.id
      WHERE rl.slug = ${slug} 
      AND rl.is_active = true
    `;

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'الرابط غير موجود أو منتهي الصلاحية' },
        { status: 404 }
      );
    }

    const linkData = result[0];

    // تنسيق البيانات المرجعة
    const response = {
      link: {
        id: linkData.link_id,
        slug: linkData.slug,
        item_type: linkData.item_type,
        item_id: linkData.product_id || linkData.offer_id,
        reseller: {
          user_id: linkData.user_id,
          name: linkData.reseller_name || 'مستخدم غير معروف',
          phone: linkData.reseller_phone || 'غير متوفر'
        },
        custom_price: linkData.reseller_price,
        is_active: linkData.is_active,
        expires_at: null,
        stats: {
          views: 1,
          clicks: 0
        }
      },
      item: linkData.item_type === 'product' ? {
        id: linkData.product_id,
        name: linkData.product_name,
        description: linkData.product_description,
        original_price: linkData.product_price,
        custom_price: linkData.reseller_price,
        final_price: linkData.reseller_price || linkData.product_price,
        image_url: linkData.product_image_url || "https://res.cloudinary.com/dldvpyait/image/upload/v1703123456/placeholder_product_400x400.png",
        category: linkData.product_category,
        stock_quantity: linkData.product_stock
      } : {
        id: linkData.offer_id,
        name: linkData.offer_name,
        description: linkData.offer_description,
        original_price: linkData.offer_price,
        custom_price: linkData.reseller_price,
        final_price: linkData.reseller_price || linkData.offer_price,
        image_url: linkData.offer_image_url || "https://res.cloudinary.com/dldvpyait/image/upload/v1703123456/placeholder_product_400x400.png",
        category: linkData.offer_category,
        stock_quantity: linkData.offer_stock
      }
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('خطأ في جلب بيانات رابط إعادة البيع:', error);
    return NextResponse.json(
      { error: 'خطأ في الخادم' },
      { status: 500 }
    );
  }
}