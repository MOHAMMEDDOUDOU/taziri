'use client';

import { useState } from 'react';
import ResellLinkCreator from '@/components/ResellLinkCreator';

// بيانات تجريبية
const mockProducts = [
  {
    id: '550e8400-e29b-41d4-a716-446655440000',
    name: 'كريم العناية بالبشرة',
    price: 2500,
    image_url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    category: 'العناية بالبشرة'
  },
  {
    id: '550e8400-e29b-41d4-a716-446655440001',
    name: 'عطر فاخر',
    price: 3500,
    image_url: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=400',
    category: 'العطور'
  }
];

const mockOffers = [
  {
    id: '550e8400-e29b-41d4-a716-446655440002',
    name: 'عرض خاص - مجموعة تجميل',
    price: 5000,
    image_url: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    category: 'مجموعات'
  }
];

const mockUser = {
  id: '550e8400-e29b-41d4-a716-446655440003',
  full_name: 'أحمد محمد',
  phone_number: '+213123456789'
};

export default function TestResellPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">اختبار نظام روابط إعادة البيع</h1>
          <p className="text-gray-600">صفحة اختبار لجميع ميزات النظام</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* معلومات النظام */}
          <div className="space-y-4">
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold mb-4">معلومات النظام</h2>
              <div className="space-y-2 text-sm">
                <p><strong>حالة الجدول:</strong> ✅ تم إنشاؤه بنجاح</p>
                <p><strong>API Endpoints:</strong> ✅ جاهزة</p>
                <p><strong>صفحة العرض:</strong> ✅ جاهزة</p>
                <p><strong>مكون الإنشاء:</strong> ✅ جاهز</p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold mb-4">البيانات التجريبية</h2>
              <div className="space-y-2 text-sm">
                <p><strong>المنتجات:</strong> {mockProducts.length} منتج</p>
                <p><strong>العروض:</strong> {mockOffers.length} عرض</p>
                <p><strong>المستخدم:</strong> {mockUser.full_name}</p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold mb-4">روابط الاختبار</h2>
              <div className="space-y-2 text-sm">
                <p><strong>API إنشاء رابط:</strong> POST /api/resell-links</p>
                <p><strong>API جلب رابط:</strong> GET /api/resell-links/[slug]</p>
                <p><strong>صفحة عرض:</strong> /resell/[slug]</p>
              </div>
            </div>
          </div>

          {/* مكون إنشاء الروابط */}
          <div>
            <ResellLinkCreator 
              products={mockProducts}
              offers={mockOffers}
              user={mockUser}
            />
          </div>
        </div>

        {/* تعليمات الاختبار */}
        <div className="mt-8 bg-blue-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">تعليمات الاختبار</h3>
          <ol className="list-decimal list-inside space-y-2 text-sm">
            <li>اختر منتج أو عرض من القائمة</li>
            <li>أدخل سعر مخصص (اختياري)</li>
            <li>اضغط على "إنشاء رابط إعادة البيع"</li>
            <li>انسخ الرابط المولد</li>
            <li>افتح الرابط في نافذة جديدة</li>
            <li>اختبر زر التواصل وزر الطلب</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
