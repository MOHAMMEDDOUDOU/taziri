"use client"

import NotFoundPage from "@/components/NotFoundPage"

export default function ProfilePage() {
  return <NotFoundPage />
}
