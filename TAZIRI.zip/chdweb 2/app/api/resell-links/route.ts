import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/neonClient';

// POST /api/resell-links - إنشاء رابط إعادة بيع جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      item_type,
      item_id,
      reseller_user_id,
      reseller_name,
      reseller_phone,
      custom_price,
      expires_at
    } = body;

    // التحقق من البيانات المطلوبة
    if (!item_type || !item_id) {
      return NextResponse.json(
        { error: 'نوع العنصر ومعرف العنصر مطلوبان' },
        { status: 400 }
      );
    }

    if (!reseller_user_id && (!reseller_name || !reseller_phone)) {
      return NextResponse.json(
        { error: 'يجب توفير معرف المستخدم أو اسم البائع ورقم الهاتف' },
        { status: 400 }
      );
    }

    // التحقق من وجود المنتج/العرض
    let itemExists = false;
    if (item_type === 'product') {
      const productResult = await pool.query(
        'SELECT id FROM products WHERE id = $1 AND is_active = true',
        [item_id]
      );
      itemExists = productResult.rows.length > 0;
    } else if (item_type === 'offer') {
      const offerResult = await pool.query(
        'SELECT id FROM offers WHERE id = $1',
        [item_id]
      );
      itemExists = offerResult.rows.length > 0;
    }

    if (!itemExists) {
      return NextResponse.json(
        { error: 'المنتج أو العرض غير موجود' },
        { status: 404 }
      );
    }

    // إنشاء رابط إعادة البيع
    const result = await pool.query(`
      INSERT INTO resell_links (
        slug,
        item_type,
        item_id,
        reseller_user_id,
        reseller_name,
        reseller_phone,
        custom_price,
        expires_at
      ) VALUES (
        lower(substring(md5(random()::text) from 1 for 8)),
        $1, $2, $3, $4, $5, $6, $7
      ) RETURNING *
    `, [
      item_type,
      item_id,
      reseller_user_id || null,
      reseller_name || null,
      reseller_phone || null,
      custom_price || null,
      expires_at || null
    ]);

    const newLink = result.rows[0];

    // جلب بيانات المنتج/العرض
    let itemData = null;
    if (item_type === 'product') {
      const productResult = await pool.query(
        'SELECT name, price, image_url, category FROM products WHERE id = $1',
        [item_id]
      );
      if (productResult.rows.length > 0) {
        itemData = productResult.rows[0];
      }
    } else if (item_type === 'offer') {
      const offerResult = await pool.query(
        'SELECT name, price, image_url, category FROM offers WHERE id = $1',
        [item_id]
      );
      if (offerResult.rows.length > 0) {
        itemData = offerResult.rows[0];
      }
    }

    const response = {
      success: true,
      link: {
        id: newLink.id,
        slug: newLink.slug,
        item_type: newLink.item_type,
        item_id: newLink.item_id,
        reseller: {
          user_id: newLink.reseller_user_id,
          name: newLink.reseller_name,
          phone: newLink.reseller_phone
        },
        custom_price: newLink.custom_price,
        expires_at: newLink.expires_at,
        created_at: newLink.created_at
      },
      item: itemData ? {
        name: itemData.name,
        original_price: itemData.price,
        custom_price: newLink.custom_price,
        final_price: newLink.custom_price || itemData.price,
        image_url: itemData.image_url,
        category: itemData.category
      } : null,
      share_url: `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/resell/${newLink.slug}`
    };

    return NextResponse.json(response, { status: 201 });

  } catch (error) {
    console.error('خطأ في إنشاء رابط إعادة البيع:', error);
    return NextResponse.json(
      { error: 'خطأ في الخادم' },
      { status: 500 }
    );
  }
}

// GET /api/resell-links - جلب روابط إعادة البيع للمستخدم
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('user_id');
    const itemId = searchParams.get('item_id');
    const itemType = searchParams.get('item_type');

    let query = `
      SELECT 
        rl.*,
        p.name as product_name,
        p.price as product_price,
        p.image_url as product_image_url,
        o.name as offer_name,
        o.price as offer_price,
        o.image_url as offer_image_url
      FROM resell_links rl
      LEFT JOIN products p ON rl.item_type = 'product' AND rl.item_id = p.id
      LEFT JOIN offers o ON rl.item_type = 'offer' AND rl.item_id = o.id
      WHERE rl.is_active = true
    `;
    const params: any[] = [];
    let paramIndex = 1;

    if (userId) {
      query += ` AND rl.reseller_user_id = $${paramIndex}`;
      params.push(userId);
      paramIndex++;
    }

    if (itemId && itemType) {
      query += ` AND rl.item_id = $${paramIndex} AND rl.item_type = $${paramIndex + 1}`;
      params.push(itemId, itemType);
    }

    query += ` ORDER BY rl.created_at DESC`;

    const result = await pool.query(query, params);

    const links = result.rows.map(row => ({
      id: row.id,
      slug: row.slug,
      item_type: row.item_type,
      item_id: row.item_id,
      reseller: {
        user_id: row.reseller_user_id,
        name: row.reseller_name,
        phone: row.reseller_phone
      },
      custom_price: row.custom_price,
      is_active: row.is_active,
      expires_at: row.expires_at,
      stats: {
        views: row.views_count,
        clicks: row.clicks_count
      },
      item: {
        name: row.item_type === 'product' ? row.product_name : row.offer_name,
        original_price: row.item_type === 'product' ? row.product_price : row.offer_price,
        custom_price: row.custom_price,
        final_price: row.custom_price || (row.item_type === 'product' ? row.product_price : row.offer_price),
        image_url: row.item_type === 'product' ? row.product_image_url : row.offer_image_url
      },
      share_url: `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/resell/${row.slug}`,
      created_at: row.created_at
    }));

    return NextResponse.json({ links });

  } catch (error) {
    console.error('خطأ في جلب روابط إعادة البيع:', error);
    return NextResponse.json(
      { error: 'خطأ في الخادم' },
      { status: 500 }
    );
  }
}
