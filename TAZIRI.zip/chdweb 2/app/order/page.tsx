import NotFoundPage from "@/components/NotFoundPage"

export default function OrderPage() {
  return <NotFoundPage />
}
