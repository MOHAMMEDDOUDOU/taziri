"use client"

import NotFoundPage from "@/components/NotFoundPage"

export default function CartPage() {
  return <NotFoundPage />
}
