const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkResellLinksTable() {
  const client = await pool.connect();
  
  try {
    console.log('🔍 التحقق من جدول resell_links...');

    // التحقق من وجود الجدول
    const tableExists = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'resell_links'
      );
    `);
    
    if (tableExists.rows[0].exists) {
      console.log('✅ جدول resell_links موجود');
      
      // عرض هيكل الجدول
      const columns = await client.query(`
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns 
        WHERE table_name = 'resell_links'
        ORDER BY ordinal_position;
      `);
      
      console.log('📋 هيكل جدول resell_links:');
      columns.rows.forEach(col => {
        console.log(`  - ${col.column_name}: ${col.data_type} (${col.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
      });
      
    } else {
      console.log('❌ جدول resell_links غير موجود');
    }

  } catch (error) {
    console.error('❌ خطأ في التحقق من الجدول:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

checkResellLinksTable().catch(console.error);
