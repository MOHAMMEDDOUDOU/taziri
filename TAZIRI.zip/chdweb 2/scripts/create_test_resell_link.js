const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function createTestResellLink() {
  const client = await pool.connect();
  
  try {
    console.log('🚀 إنشاء رابط بيع تجريبي للاختبار...');

    // إنشاء مستخدم تجريبي أولاً
    const userResult = await client.query(`
      INSERT INTO users (id, username, password_hash, full_name, phone_number, role, created_at)
      VALUES (
        gen_random_uuid(),
        'test_seller',
        'hashed_password',
        'بائع تجريبي',
        '0550123457',
        'user',
        NOW()
      )
      RETURNING id;
    `);
    
    const userId = userResult.rows[0].id;
    console.log('✅ تم إنشاء المستخدم التجريبي:', userId);

    // إنشاء منتج تجريبي
    const productResult = await client.query(`
      INSERT INTO products (id, name, description, price, category, image_url, created_at)
      VALUES (
        gen_random_uuid(),
        'منتج تجريبي للاختبار',
        'وصف المنتج التجريبي',
        1500.00,
        'إلكترونيات',
        'https://via.placeholder.com/400x400?text=منتج+تجريبي',
        NOW()
      )
      RETURNING id;
    `);
    
    const productId = productResult.rows[0].id;
    console.log('✅ تم إنشاء المنتج التجريبي:', productId);

    // إنشاء رابط بيع تجريبي
    const resellLinkResult = await client.query(`
      INSERT INTO resell_links (id, product_id, user_id, slug, is_active, created_at, item_type, reseller_price)
      VALUES (
        gen_random_uuid(),
        $1,
        $2,
        'test-offer-123',
        true,
        NOW(),
        'product',
        1800.00
      )
      RETURNING id, slug;
    `, [productId, userId]);
    
    const resellLink = resellLinkResult.rows[0];
    console.log('✅ تم إنشاء رابط البيع التجريبي:', resellLink.slug);
    console.log('🔗 رابط الاختبار: http://localhost:3000/resell/test-offer-123');

    return {
      userId,
      productId,
      resellLinkId: resellLink.id,
      slug: resellLink.slug
    };

  } catch (error) {
    console.error('❌ خطأ في إنشاء البيانات التجريبية:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

createTestResellLink().catch(console.error);
