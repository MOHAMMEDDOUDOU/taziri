require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkTableStructure() {
  try {
    console.log('🔍 التحقق من هيكل جدول resell_links...');
    
    const result = await pool.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'resell_links' 
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 أعمدة جدول resell_links:');
    result.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type} (${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
    });

    console.log('\n🔍 التحقق من هيكل جدول products...');
    
    const productsResult = await pool.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'products' 
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 أعمدة جدول products:');
    productsResult.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type} (${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
    });

    console.log('\n🔍 التحقق من هيكل جدول users...');
    
    const usersResult = await pool.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 أعمدة جدول users:');
    usersResult.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type} (${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
    });

  } catch (error) {
    console.error('❌ خطأ في التحقق من هيكل الجدول:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

if (require.main === module) {
  checkTableStructure()
    .then(() => {
      console.log('\n✅ تم الانتهاء من التحقق من هيكل الجداول');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ فشل في التحقق من هيكل الجداول:', error);
      process.exit(1);
    });
}

module.exports = { checkTableStructure };
