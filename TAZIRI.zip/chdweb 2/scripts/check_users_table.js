const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkUsersTable() {
  const client = await pool.connect();
  
  try {
    console.log('🔍 التحقق من جدول users...');

    // التحقق من وجود الجدول
    const tableExists = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users'
      );
    `);
    
    if (tableExists.rows[0].exists) {
      console.log('✅ جدول users موجود');
      
      // عرض هيكل الجدول
      const columns = await client.query(`
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns 
        WHERE table_name = 'users'
        ORDER BY ordinal_position;
      `);
      
      console.log('📋 هيكل جدول users:');
      columns.rows.forEach(col => {
        console.log(`  - ${col.column_name}: ${col.data_type} (${col.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
      });
      
    } else {
      console.log('❌ جدول users غير موجود');
    }

  } catch (error) {
    console.error('❌ خطأ في التحقق من الجدول:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

checkUsersTable().catch(console.error);
