const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function testDirectDbInsert() {
  const client = await pool.connect();
  
  try {
    console.log('🧪 اختبار إدراج طلب مباشرة في قاعدة البيانات...');

    // إنشاء طلب تجريبي
    const insertQuery = `
      INSERT INTO orders (
        item_type,
        item_id,
        item_name,
        quantity,
        unit_price,
        subtotal,
        shipping_cost,
        total_amount,
        customer_name,
        phone_number,
        wilaya,
        commune,
        delivery_type,
        status,
        reseller_price,
        reseller_name,
        reseller_phone,
        reseller_user_id,
        order_link
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
      RETURNING id, created_at
    `;

    const values = [
      'product',
      '8dae8c99-2655-41b1-91b1-7e6a088d3712',
      'منتج تجريبي للاختبار المباشر',
      1,
      1800.00,
      1800.00,
      0,
      1800.00,
      'عميل تجريبي مباشر',
      '0550123462',
      '16',
      'بلدية تجريبية',
      'home',
      'pending',
      1800.00,
      'بائع تجريبي',
      '0550123457',
      '628b27dc-dff1-490d-9b3b-b97ec4260caf',
      'resell/test-direct-insert'
    ];

    console.log('📤 إدراج البيانات:', JSON.stringify(values, null, 2));

    const result = await client.query(insertQuery, values);
    const order = result.rows[0];
    
    console.log('✅ تم إدراج الطلب بنجاح!');
    console.log('🆔 معرف الطلب:', order.id);
    console.log('📅 تاريخ الإنشاء:', order.created_at);

    // التحقق من وجود الطلب
    const checkQuery = await client.query(`
      SELECT * FROM orders WHERE id = $1
    `, [order.id]);

    if (checkQuery.rows.length > 0) {
      console.log('✅ تم العثور على الطلب في قاعدة البيانات:');
      console.log(JSON.stringify(checkQuery.rows[0], null, 2));
    } else {
      console.log('❌ لم يتم العثور على الطلب في قاعدة البيانات');
    }

  } catch (error) {
    console.error('❌ خطأ في إدراج الطلب:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

testDirectDbInsert().catch(console.error);
