require('dotenv').config();
const { Pool } = require('pg');

async function createResellLinksTable() {
  console.log('🔧 إنشاء جدول روابط إعادة البيع...');
  
  if (!process.env.NEON_DATABASE_URL) {
    console.error('❌ متغير NEON_DATABASE_URL غير موجود');
    return;
  }

  const pool = new Pool({
    connectionString: process.env.NEON_DATABASE_URL,
    ssl: { rejectUnauthorized: false }
  });

  try {
    // قراءة ملف SQL الأساسي
    const fs = require('fs');
    const path = require('path');
    const sqlFile = path.join(__dirname, '../database/resell-links-basic.sql');
    
    if (!fs.existsSync(sqlFile)) {
      console.error('❌ ملف database/resell-links-basic.sql غير موجود');
      return;
    }

    const sqlContent = fs.readFileSync(sqlFile, 'utf8');
    
    // تنفيذ أوامر SQL
    console.log('📝 تنفيذ أوامر SQL...');
    await pool.query(sqlContent);
    
    console.log('✅ تم إنشاء جدول روابط إعادة البيع بنجاح!');

    // التحقق من الجداول
    const tablesResult = await pool.query(`
      SELECT table_name FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'resell_links'
      ORDER BY table_name;
    `);
    
    console.log('📊 الجداول الموجودة:', tablesResult.rows.map(row => row.table_name));

    // التحقق من هيكل الجدول
    const columnsResult = await pool.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'resell_links' 
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 أعمدة جدول روابط إعادة البيع:');
    columnsResult.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type} (${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
    });

    console.log('🎉 تم إنشاء نظام روابط إعادة البيع بنجاح!');

  } catch (error) {
    console.error('❌ خطأ في إنشاء جدول روابط إعادة البيع:', error.message);
  } finally {
    await pool.end();
  }
}

createResellLinksTable();
