const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL || process.env.DATABASE_URL,
});

async function createTestData() {
  try {
    console.log('بدء إنشاء البيانات التجريبية...');

    // استخدام المستخدم الأول الموجود
    const userResult = await pool.query('SELECT id, username, full_name, phone_number FROM users LIMIT 1');
    const userId = userResult.rows[0].id;
    console.log('تم العثور على مستخدم:', userResult.rows[0]);

    // إنشاء منتج تجريبي
    const productResult = await pool.query(`
      INSERT INTO products (id, name, description, price, image_url, category, stock_quantity, is_active, created_at, updated_at)
      VALUES (
        gen_random_uuid(),
        'هاتف ذكي تجريبي',
        'هاتف ذكي حديث مع كاميرا عالية الجودة',
        25000,
        'https://res.cloudinary.com/dldvpyait/image/upload/v1703123456/placeholder_product_400x400.png',
        'إلكترونيات',
        50,
        true,
        NOW(),
        NOW()
      )
      RETURNING id
    `);

    const productId = productResult.rows[0].id;
    console.log('تم إنشاء المنتج:', productId);

    // إنشاء رابط إعادة بيع تجريبي
    const resellLinkResult = await pool.query(`
      INSERT INTO resell_links (id, slug, item_type, product_id, user_id, reseller_price, is_active, created_at)
      VALUES (
        gen_random_uuid(),
        'og7ctmMHO83i',
        'product',
        $1,
        $2,
        28000,
        true,
        NOW()
      )
      ON CONFLICT (slug) DO UPDATE SET
        product_id = EXCLUDED.product_id,
        user_id = EXCLUDED.user_id,
        reseller_price = EXCLUDED.reseller_price,
        is_active = EXCLUDED.is_active
      RETURNING id, slug
    `, [productId, userId]);

    console.log('تم إنشاء رابط إعادة البيع:', resellLinkResult.rows[0]);

    console.log('✅ تم إنشاء جميع البيانات التجريبية بنجاح!');
    console.log('يمكنك الآن اختبار الرابط: /resell/og7ctmMHO83i');

  } catch (error) {
    console.error('❌ خطأ في إنشاء البيانات التجريبية:', error);
  } finally {
    await pool.end();
  }
}

createTestData();
