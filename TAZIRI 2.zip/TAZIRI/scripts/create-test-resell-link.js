require('dotenv').config();
const { Pool } = require('pg');

// تكوين الاتصال بقاعدة البيانات
const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function createTestResellLink() {
  try {
    console.log('🔧 إنشاء رابط إعادة بيع تجريبي...');
    
    // أولاً، إنشاء منتج تجريبي إذا لم يكن موجوداً
    const productResult = await pool.query(`
      INSERT INTO products (
        id, name, description, price, image_url, stock_quantity, category, is_active
      ) VALUES (
        '550e8400-e29b-41d4-a716-446655440000',
        'منتج تجريبي للاختبار',
        'هذا منتج تجريبي لاختبار نظام إعادة البيع',
        2000,
        'https://via.placeholder.com/400x400?text=منتج+تجريبي',
        10,
        'إلكترونيات',
        true
      ) ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        description = EXCLUDED.description,
        price = EXCLUDED.price,
        image_url = EXCLUDED.image_url,
        stock_quantity = EXCLUDED.stock_quantity,
        category = EXCLUDED.category,
        is_active = EXCLUDED.is_active
      RETURNING *
    `);
    
    console.log('✅ تم إنشاء/تحديث المنتج التجريبي');

    // إنشاء مستخدم تجريبي
    const userResult = await pool.query(`
      INSERT INTO users (
        id, username, full_name, phone_number, password_hash, is_active
      ) VALUES (
        '550e8400-e29b-41d4-a716-446655440001',
        'ahmed_test',
        'أحمد محمد',
        '+213123456789',
        'test_password_hash',
        true
      ) ON CONFLICT (id) DO UPDATE SET
        username = EXCLUDED.username,
        full_name = EXCLUDED.full_name,
        phone_number = EXCLUDED.phone_number,
        password_hash = EXCLUDED.password_hash,
        is_active = EXCLUDED.is_active
      RETURNING *
    `);
    
    console.log('✅ تم إنشاء/تحديث المستخدم التجريبي');

    // إنشاء رابط إعادة البيع التجريبي
    const resellLinkResult = await pool.query(`
      INSERT INTO resell_links (
        slug, item_type, product_id, user_id, is_active
      ) VALUES (
        'test-offer-123',
        'product',
        '550e8400-e29b-41d4-a716-446655440000',
        '550e8400-e29b-41d4-a716-446655440001',
        true
      ) ON CONFLICT (slug) DO UPDATE SET
        item_type = EXCLUDED.item_type,
        product_id = EXCLUDED.product_id,
        user_id = EXCLUDED.user_id,
        is_active = EXCLUDED.is_active
      RETURNING *
    `);
    
    console.log('✅ تم إنشاء رابط إعادة البيع التجريبي:', resellLinkResult.rows[0].slug);

    // اختبار جلب البيانات
    console.log('\n🧪 اختبار جلب البيانات...');
    const testData = await pool.query(`
      SELECT 
        rl.id as link_id,
        rl.slug,
        rl.item_type,
        rl.product_id,
        rl.user_id,
        p.name as product_name,
        p.description as product_description,
        p.price as product_price,
        p.image_url as product_image_url,
        p.category as product_category,
        p.stock_quantity as product_stock,
        rl.is_active
      FROM resell_links rl
      LEFT JOIN products p ON rl.item_type = 'product' AND rl.product_id = p.id AND p.is_active = true
      WHERE rl.slug = 'test-offer-123' 
      AND rl.is_active = true
    `);

    if (testData.rows.length > 0) {
      console.log('✅ تم جلب البيانات بنجاح!');
      console.log('📋 البيانات:');
      console.log('- الرابط المختصر:', testData.rows[0].slug);
      console.log('- اسم المنتج:', testData.rows[0].product_name);
      console.log('- السعر:', testData.rows[0].product_price);
      console.log('- الفئة:', testData.rows[0].product_category);
    } else {
      console.log('❌ لم يتم العثور على البيانات');
    }

    console.log('\n🎯 الروابط للاختبار:');
    console.log('- صفحة العرض: http://localhost:3000/resell/test-offer-123');
    console.log('- صفحة الطلب: http://localhost:3000/resell/test-offer-123/order');

  } catch (error) {
    console.error('❌ خطأ في إنشاء الرابط التجريبي:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// تشغيل السكريبت إذا تم استدعاء الملف مباشرة
if (require.main === module) {
  createTestResellLink()
    .then(() => {
      console.log('\n✅ تم الانتهاء من إنشاء الرابط التجريبي');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ فشل في إنشاء الرابط التجريبي:', error);
      process.exit(1);
    });
}

module.exports = { createTestResellLink };
