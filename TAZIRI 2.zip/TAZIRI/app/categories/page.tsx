import NotFoundPage from "@/components/NotFoundPage"

export default function CategoriesPage() {
  return <NotFoundPage />
}
