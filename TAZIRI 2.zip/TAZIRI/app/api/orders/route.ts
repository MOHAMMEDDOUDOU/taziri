import { NextRequest, NextResponse } from 'next/server';
import { Pool } from 'pg';
import { WILAYAS as WILAYAS_DATA } from '@/lib/locations';

let baseConnectionString = process.env.NEON_DATABASE_URL || process.env.DATABASE_URL || '';
if (!process.env.NEON_DATABASE_URL && process.env.DATABASE_URL) {
  console.warn('[orders API] NEON_DATABASE_URL غير معرف. سيتم استخدام DATABASE_URL كبديل.');
}

// محاولة إجبار الاتصال على RW إذا كان المضيف يحتوي على -pooler
function toReadWriteConn(str: string): string {
  try {
    const url = new URL(str);
    if (url.hostname.includes('-pooler.')) {
      url.hostname = url.hostname.replace('-pooler.', '.');
    }
    // إجبار target_session_attrs=read-write
    url.searchParams.set('target_session_attrs', 'read-write');
    url.searchParams.set('sslmode', 'require');
    return url.toString();
  } catch {
    return str;
  }
}

const rwConnectionString = toReadWriteConn(baseConnectionString);

const pool = new Pool({
  connectionString: rwConnectionString,
  ssl: {
    rejectUnauthorized: false
  }
});

function normalizeDigits(input: string | null | undefined): string {
  if (!input) return '';
  const arabicIndic = '٠١٢٣٤٥٦٧٨٩';
  const easternArabicIndic = '۰۱۲۳۴۵۶۷۸۹';
  let out = '';
  for (const ch of input) {
    const i1 = arabicIndic.indexOf(ch);
    if (i1 !== -1) { out += String(i1); continue; }
    const i2 = easternArabicIndic.indexOf(ch);
    if (i2 !== -1) { out += String(i2); continue; }
    if (/\d/.test(ch)) { out += ch; continue; }
    if (/\s|[+\-()]/.test(ch)) continue;
    out += ch;
  }
  return out;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      resell_link_id,
      item_type,
      item_id,
      item_name,
      original_price,
      reseller_price,
      quantity,
      total_amount,
      seller_id,
      seller_name,
      seller_phone,
      customer_name,
      customer_phone,
      delivery_type,
      wilaya,
      commune,
      notes
    } = body;

    if (!resell_link_id || !item_type || !item_id || !item_name || 
        !original_price || !reseller_price || !quantity || !customer_name || !customer_phone || !delivery_type || !wilaya) {
      return NextResponse.json(
        { error: 'جميع الحقول المطلوبة يجب أن تكون موجودة' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      await client.query("SET search_path TO public");
      await client.query("SET default_transaction_read_only = off");
      console.log('🔍 بدء عملية حفظ الطلب...');
      console.log('📤 البيانات المستلمة:', JSON.stringify(body, null, 2));
      console.log('🗄️ الاتصال بقاعدة البيانات:', new URL(rwConnectionString).hostname);
      
      const normalizedPhone = normalizeDigits(customer_phone);
      console.log('📞 normalizedPhone:', normalizedPhone);

      // جلب معلومات رابط إعادة البيع لضمان الاسم والسعر الصحيحين
      const rlRes = await client.query(
        `SELECT rl.user_id, rl.reseller_price, rl.item_type
         FROM resell_links rl
         WHERE rl.id = $1 LIMIT 1`,
        [resell_link_id]
      );

      if (rlRes.rowCount === 0) {
        return NextResponse.json({ error: 'رابط البيع غير موجود' }, { status: 400 });
      }

      const rlRow = rlRes.rows[0] as { user_id: string | null; reseller_price: number | null; item_type: string | null };

      // جلب بيانات المستخدم (الموزّع)
      let resellerNameDb: string | null = null;
      let resellerPhoneDb: string | null = null;
      if (rlRow.user_id) {
        const userRes = await client.query(
          `SELECT full_name, username, phone_number FROM users WHERE id = $1 LIMIT 1`,
          [rlRow.user_id]
        );
        if (userRes.rowCount > 0) {
          const u = userRes.rows[0] as { full_name: string | null; username: string | null; phone_number: string | null };
          resellerNameDb = (u.full_name && u.full_name.trim()) || (u.username && u.username.trim()) || null;
          resellerPhoneDb = u.phone_number || null;
        }
      }

      // تحديد سعر الوحدة النهائي
      const unitPriceFinal = (rlRow.reseller_price != null ? Number(rlRow.reseller_price) : Number(reseller_price)) || Number(original_price);
      const qty = Number(quantity) || 1;
      const subtotalFinal = unitPriceFinal * qty;

      // حساب تكلفة الشحن من تعريفات الولايات
      const wilayaNum = Number(wilaya);
      const wilayaRow = WILAYAS_DATA.find(w => w.code === wilayaNum);
      const shippingCostFinal = delivery_type === 'home'
        ? (wilayaRow?.tarif || 0)
        : (wilayaRow?.stopDesk || 0);

      const totalFinal = subtotalFinal + shippingCostFinal;

      await client.query('BEGIN');

      const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      const insertQuery = `
        INSERT INTO orders (
          item_type,
          item_id,
          item_name,
          quantity,
          unit_price,
          subtotal,
          shipping_cost,
          total_amount,
          customer_name,
          phone_number,
          wilaya,
          commune,
          delivery_type,
          status,
          reseller_price,
          reseller_name,
          reseller_phone,
          reseller_user_id,
          order_link
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
        RETURNING id, created_at
      `;

      const values = [
        item_type,
        item_id,
        item_name,
        qty,
        unitPriceFinal,
        subtotalFinal,
        shippingCostFinal,
        totalFinal,
        customer_name,
        normalizedPhone,
        String(wilaya),
        commune || null,
        delivery_type,
        'pending',
        unitPriceFinal,
        resellerNameDb,
        resellerPhoneDb,
        rlRow.user_id || null,
        `resell/${resell_link_id}`
      ];

      console.log('📝 تنفيذ استعلام الإدراج...');
      console.log('📋 القيم:', JSON.stringify(values, null, 2));
      
      const result = await client.query(insertQuery, values);
      const order = result.rows[0];
      
      console.log('✅ تم إدراج الطلب بنجاح:', order.id);

      await client.query('COMMIT');
      console.log('🟢 COMMIT تم بنجاح');

      return NextResponse.json({
        success: true,
        message: 'تم حفظ الطلب بنجاح',
        order: {
          id: order.id,
          order_number: orderNumber,
          created_at: order.created_at
        },
        db: new URL(rwConnectionString).hostname
      });

    } catch (error) {
      await client.query('ROLLBACK');
      console.error('🔴 ROLLBACK بسبب خطأ:', error);
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('خطأ في حفظ الطلب:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء حفظ الطلب' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const customerPhoneRaw = searchParams.get('customer_phone');
    const status = searchParams.get('status');

    const client = await pool.connect();

    try {
      await client.query("SET search_path TO public");
      await client.query("SET default_transaction_read_only = off");
      let query = `
        SELECT 
          o.*
        FROM orders o
        WHERE 1=1
      `;
      
      const values: any[] = [];
      let paramCount = 0;

      if (customerPhoneRaw) {
        const customerPhone = normalizeDigits(customerPhoneRaw);
        console.log('🔎 filter phone normalized:', customerPhone);
        paramCount++;
        query += ` AND o.phone_number = $${paramCount}`;
        values.push(customerPhone);
      }

      if (status) {
        paramCount++;
        query += ` AND o.status = $${paramCount}`;
        values.push(status);
      }

      query += ` ORDER BY o.created_at DESC`;

      const result = await client.query(query, values);

      return NextResponse.json({
        success: true,
        db: new URL(rwConnectionString).hostname,
        count: result.rows.length,
        orders: result.rows
      });

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('خطأ في جلب الطلبات:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الطلبات' },
      { status: 500 }
    );
  }
}
